export class Post {
    title: string='';
    body: string='';
}
